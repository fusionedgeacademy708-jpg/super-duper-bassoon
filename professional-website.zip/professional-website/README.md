# Kehinde Ebenezer — Professional Identity Platform

Strategic Communication Professional & Founder of **Fusionedge Digital Bootcamp Academy**

## Your details (live on the site)

- **Name**: Kehinde Ebenezer  
- **Business**: Fusionedge Digital Bootcamp Academy  
- **Email**: oladejibabatunde114@gmail.com  
- **WhatsApp**: +234 913 772 1141  
- **LinkedIn**: linkedin.com/in/kehindeebenezer (update the URL if your real profile differs)

## Design

- **Backgrounds**: Clean bright white + very light off-white (no dull grey wash)
- **Accent**: Deep emerald green (`#0c5c4d`) — **no blue**
- Professional, clean, trustworthy, corporate
- Fully responsive

## Sections

1. Homepage  
2. About (includes Fusionedge Digital Bootcamp Academy)  
3. Services  
4. Portfolio (12 filterable samples)  
5. Case Studies  
6. Insights  
7. Resources  
8. Contact (your real email + WhatsApp)

## How to view

Open `index.html` in any browser. No build step needed.

## Next steps

1. Replace the “KE” placeholder with a professional headshot  
2. Confirm / update your real LinkedIn URL  
3. Host on Netlify, Vercel or GitHub Pages  
4. Swap sample projects for real work when ready
